Contents of A68 ZIP file Feb 15 2019 HRJ

a68.exe	32-bit Windows command-line program
a68.c		A68 sources
a68.h
a68eval.c
a68util.c

swtb2.*	MIKBUG 6800 files assembled by A68

swtbugv10.lst MIKBUG 6800 listing, Motorola assembler format

test68.*	A68 opcode test ASM file, with Intel and Motorola
           hex files. 

Assembler currently produces 16-data-byte hex records. To change
length, reassemble with a68.h value HEXSIZE changed to desired length.
